module.exports = {
	"baseUrl": "https://localhost:3000/",
	"siteName": "ETH_Simulator",
	"jwt_secret": "tradingsimulator123",
	"jwt_expire": "1d",
	"trading_symbol": "ETHUSD",
	"Discord_CLIENT_ID": "1049499468300558336",
	"Discord_CLIENT_SECRET": "5oaP9vt4pfhrxFn_TLmF-_-RNqgy91rg",
	"Discord_redirect": "http://161.35.51.70/discord-auth",
	"Twitter_CLIENT_ID": "UkZWWFF3aDl5ajFjRm51ZnNkb2o6MTpjaQ",
	"Twitter_CLIENT_SECRET": "qK-TUmQCWvxBD1ybMxCxrTaCQztxHnZoJshjARABmSQIX0h4uL",
	"Twitter_redirect": "http://161.35.51.70/twitter-auth",
	"CryptoConfig": [{
		name: "ETH",
		symbol: "ETH"
	}]
}